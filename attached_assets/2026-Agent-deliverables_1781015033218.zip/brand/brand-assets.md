# Synozur Brand Assets

**Prepared:** 2026-06-09 · **Owner:** Chris McNulty (CTO) · **For:** Copilot Cowork marketing skills library (branded-doc-generator, branded-deck-generator).
Source: Synozur design system + docx/pptx-synozur-brand skills; logo files provided by Chris.

> ⚠️ Save target is `{sharepoint_root}/brand/brand-assets.md`. Delivered to `output/brand/` — drop into `Marketing › Collateral Development › 2026 Agent › brand/`. Logo files are in `output/brand/logos/` for the matching `2026 Agent › brand › logos/` drop.

## Colors

| Role | Color | Hex |
| --- | --- | --- |
| Primary | Synozur purple | **#810FFB** |
| Secondary | Magenta | **#E60CB3** |
| Secondary | Deep purple | **#6003C3** |
| Neutral | White | **#FFFFFF** |

The primary brand expression is a **magenta → purple gradient** (#E60CB3 → #810FFB), seen in the logo mark. Deep purple (#6003C3) anchors darker fills and backgrounds; white is the reverse/knockout.

## Typography

| Role | Typeface | M365 fallback (Office) | Web / Google fallback |
| --- | --- | --- | --- |
| Headings | Avenir Next LT Pro | Segoe UI | Montserrat |
| Body | Avenir Next LT Pro | Segoe UI | Montserrat |

Avenir Next LT Pro is a **licensed desktop font** and is not bundled with Microsoft Office. Generated Word/PowerPoint files use the fallback (Segoe UI) unless the licensed font is installed on the machine opening the file; web/HTML assets use Montserrat.

## Logos

Folder: `/sites/Marketing/Collateral Development/2026 Agent/brand/logos/` — transparent PNGs, provided 2026-06-09.

| File | Variant | Dimensions | Use |
| --- | --- | --- | --- |
| `SA-Logo-Horizontal-color.png` | Horizontal lockup, full color | 717×195 | Default, on light backgrounds |
| `SA-Logo-Horizontal-white.png` | Horizontal lockup, reversed | 717×195 | On dark/brand-color backgrounds |
| `SynozurLogo_color 1400.png` | Stacked mark (@ pin + wordmark), color | 1400×1400 | Square/social, avatars, large format |
| `SynozurLogo_white 1400.png` | Stacked mark, reversed | 1400×1400 | Square on dark backgrounds |

The mark is the **@ location-pin** in the magenta→purple gradient with the "synozur" wordmark and "ALLIANCE" sub-label. Variants available: **horizontal (color + reversed)** and **stacked mark (color + reversed)**. An **icon-only** crop (pin only) and a **vector (SVG/EPS)** set are not yet provided — add if needed for small-format or print use.

## Templates

| Type | File | Notes |
| --- | --- | --- |
| Word (.docx) | `Synozur Template DOCX for Copilot.docx` | Driven by the docx-synozur-brand skill — preserves logo, header/footer, theme colors, Avenir typography. |
| PowerPoint (.pptx) | `Synozur 2026 Full File.pptx` | Synozur Brand Center; driven by the pptx-synozur-brand skill — brand layouts, master slides, theme colors. |

## Pending

- **Logo upload:** PNG files delivered to `output/brand/logos/`; need the one-time drop into `Cowork/brand/logos/` in SharePoint.
- **Vector + icon-only logo variants:** add SVG/EPS and a pin-only crop if small-format or print output is required.
