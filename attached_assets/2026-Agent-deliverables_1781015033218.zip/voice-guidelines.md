# Synozur Brand Voice Guidelines

How Synozur — and Chris McNulty as its primary public voice — actually writes. Drawn from a
Work IQ pass over real sent mail, the Polaris podcast and synozur.com, Chris's LinkedIn
articles, and the in-tenant `outbound-voice` Voice DNA (a real-mail extraction). Use this as
the canonical reference for the `copywriter` and `repurposing-engine` skills. This is the
*real* voice, not a generic descriptor.

## One-line descriptor (the `{tone}` variable)

Direct, plainspoken, anti-hype peer-to-peer authority — short declaratives, deliberate
em-dash asides, **wartime clarity**; leads with the person and the ask, always lands on a
concrete next step.

## How it sounds (characterization)

- **Cadence.** Short, stacked declaratives — period-then-period over comma-then-conjunction.
  ~19-word average with wide range; one-line fragments for emphasis ("Good note.", "Right call.").
- **Em-dash habit.** Heavy and deliberate — mid-sentence asides and setup-punchline turns
  (~1 per 60 words). Semicolons essentially never.
- **Formality: mid-low.** Cold/external opens "Hi [Name],"; peers get "[Name] —" or
  "Hey [Name],"; threaded replies drop the greeting. **Never** "I hope this message finds you well."
- **Structure when explaining.** Bold mini-headers + tight bullets, headers often followed by
  an em-dash ("Notes from the call —", "Additional candidates —").
- **Signature vocabulary.** "happy to," "would love to," "the works," "compare notes,"
  "quick context —," "quick update on timing:"; agreement tokens "Right call," "That tracks."
- **Thought-leadership register.** Opinionated reframes and quotable aphorisms — "Metadata is
  the secret sauce"; "Your AI strategy just became obsolete (again)." Seasonal recurring
  framing: "Write of Spring," "Summer of Copilot," `#AIAutumn`.
- **North Star metaphor (firm line).** Consistent across properties — "charts the course for
  business, leadership and technology transformation"; "rooted in people, powered by
  technology, and driven by purpose."
- **Anti-hype stance.** "CEOs don't need more AI hype. They need clarity, control, and
  confidence." Earned confidence, never inflation. This is the wartime register: existential,
  act-now, decisive — clarity over comfort.
- **Relationship-forward warmth.** Generous and specific, never gushing ("I have your back,
  always"). Light personal texture (Boston/Red Sox).
- **Accountability.** Owns misses plainly ("That was on me") with no over-apology paragraph.
- **Sign-offs.** "Best, Chris" (standard), "Thanks, Chris" (terse/peer), bare "Chris" or none
  (active threads); full signature block only on first-touch/substantive mail.

## What the voice avoids (banned register)

"circle back," "touch base," "leverage" (verb), "synergy," "move the needle," "deep dive,"
"world-class," "game-changer," "in today's fast-paced world," urgency-theater subject lines,
filler adjectives ("robust," "pivotal"), and reflexive rule-of-three tricolons. No AI slop —
every deliverable is human-reviewed before it ships (ASK → REVIEW → EDIT → REPEAT).

## Channel adaptation

- **LinkedIn (primary).** Opinionated long-form, ~monthly; seasonal salutations; a strong
  reframe up top, a quotable line, a clear takeaway. ~5%+ engagement is the bar.
- **Polaris podcast.** Show notes lead with the guest and one sharp idea; warm, curious,
  host-forward; CTA to subscribe/next episode.
- **Blog ("The Feed," synozur.com/insights).** Practitioner essays — pain-first, numbers when
  available, a client or field example, a decisive point of view.
- **Email.** Greeting matched to relationship; the ask in line one; bold mini-headers for
  anything multi-part; a concrete next step to close.

## Sources

Real sent mail (Outlook); `outbound-voice/voice-dna.md` (real-mail extraction, Mar–May 2026);
`chris-voice` / `my-voice` skill canon; Polaris podcast + synozur.com; Chris's LinkedIn
articles (Sep 2025–May 2026). Refresh quarterly per the `outbound-voice` re-extraction routine.
