# Copywriter — Batch 1 drafts (briefs #1, #3, #6, #7)

**Prepared:** 2026-06-07 · **Skill:** copywriter · **Voice:** Chris McNulty / Synozur (wartime, anti-hype, practitioner).
**Note:** per the copywriter skill's platform rules, these use no em dashes (your natural habit) — voice is carried via cadence, short declaratives, and concrete closers. Sentence case, no hashtags, no filler, hard CTAs.

> ⚠️ Save target is `{sharepoint_root}/drafts/`. Delivered to `output/drafts/` — drop into `Marketing › Cowork › drafts/` for repurposing-engine / seo-aeo-optimizer / distribution-planner.

---

## Brief #1 — LinkedIn post — "95% of AI pilots never scale. Here's the 5% pattern."

95% of generative AI pilots never make it past the demo. That's MIT's number, and it hasn't moved in 2026.

That's not an AI problem. It's a scaling problem.

I've watched companies greenlight three, four, five pilots in a year and still not point to a single line on the P&L. The demos looked great. Then they sat there.

The 5% that scale do three unglamorous things:

1. They turn real documents and workflows into a ranked use-case backlog. Not the demo. The actual work.

2. They stand up a governance model before they scale, not after the audit. Speed and control are not opposites.

3. They put a human owner on every AI output. No exceptions.

None of that is exciting. All of it is what separates transformation from theater.

If your pilots are stuck, the fix is rarely a better model. It's a better operating discipline.

I put the pilot-to-scale playbook together for mid-market leaders working through exactly this. Comment "playbook" and I'll send it over.

*(~1,060 characters)*

---

## Brief #3 — LinkedIn post — "No AI slop: why every deliverable needs a human owner"

Every AI deliverable we ship has a human owner. No exceptions.

That sounds obvious until you see how much work goes out the door that nobody actually read.

RAND says 80% of AI projects deliver no measurable business value. The reason usually isn't the model. It's that someone shipped the output without owning it.

So we made it a standard, not a slogan. Ask. Review. Edit. Repeat. A human is accountable in all cases.

AI accelerates the work. It does not replace the judgment. The moment you let it, you start shipping confident, polished, and wrong.

Our clients don't want more content faster. They want to trust what goes out under their name. That's the whole game.

If you're rolling AI into real workflows, write down who owns the output before you write down which tool you're using.

I put our AI judgment standard on one page. Comment "guardrails" and I'll send it.

*(~940 characters)*

---

## Brief #6 — Newsletter — "The wartime CEO's AI memo: act now, govern hard"

A Company Operating System is a peacetime discipline. AI is a wartime problem. Most leaders are running both at the wrong speeds, and it's costing them.

Here's the uncomfortable math. FTI's 2026 work shows 66% of private equity firms now see measurable AI benefit within a year, and the gap between the high performers and everyone else is widening fast. BCG puts it bluntly: portfolio companies that build AI across functions are running roughly twice the return on invested capital of the ones that don't. The window where "we're watching it closely" counted as a strategy is closing.

So wartime, yes. But wartime does not mean reckless. The same research found only 9% of PE leaders are confident they could pass an AI governance audit in 90 days. Speed without control is how you end up explaining yourself in a headline you didn't write.

If I were running a mid-market company right now, this is the memo I'd write to myself.

Pick the war. One or two use cases tied to real money. Not twelve pilots competing for attention.

Govern before you scale. Decide who owns the output, what data it touches, and how you'd defend it if someone asked tomorrow.

Put a deadline on it. Four to six weeks to a working prototype beats a six-month strategy deck that ages on a shelf.

Land it with the people doing the work. Middle managers and individual contributors, not leadership theater. The value shows up where the work happens or it doesn't show up at all.

None of this requires more AI hype. You have plenty of that already. What you need is clarity on where AI earns its keep, control over how it's used, and the confidence to move while your competitors are still forming a committee.

The companies pulling ahead this year are not the ones with the most pilots. They're the ones who picked a fight, governed it, and shipped.

We run a Free Strategy Day for CEOs and their boards to do exactly that, in a room, in a day. Reply to this and I'll get you on the calendar.

*(~485 words)*

---

## Brief #7 — X thread — "7 signs your AI program is theater, not transformation"

**1/** 42% of companies scrapped most of their AI initiatives this year. Most of them didn't have an AI problem. They had a theater problem. 7 signs your AI program is theater, not transformation:

**2/** You can count your pilots but not your P&L impact. Five demos and zero dollars is not progress. It's activity wearing a strategy costume.

**3/** Nobody owns the output. If AI writes it and no human signs it, you're not scaling productivity. You're scaling slop, faster.

**4/** Governance is a slide, not a system. "We'll handle compliance later" is the most expensive sentence in enterprise AI. Only 9% of leaders say they'd pass an audit in 90 days.

**5/** It's all leadership theater. The execs are energized. The people who actually do the work never got trained, asked, or equipped. Adoption dies in that gap.

**6/** You're married to one vendor. The right answer isn't always Copilot, or ChatGPT, or Claude. Pick the tool that fits the job, not the logo on the contract.

**7/** You measure licenses, not adoption, and every project is a demo that never becomes a deployment. 420M people have Copilot. Most use a sliver of it.

**8/** Transformation isn't more pilots. It's picking a fight, governing it, and shipping it. If your program failed this checklist, I wrote the playbook to fix it. Link in the comments.
