# Synozur Positioning Dossier

**Prepared:** 2026-06-07 · **Skill:** positioning-researcher · **For:** The Synozur Alliance
**Inputs:** confirmed `variables.md`; live competitor homepages + reviews; ICP research (LinkedIn/Reddit/industry); first-party Outlook signals (Platinum Equity, Chevron threads).
**Category:** AI-native strategic transformation advisory ("the transformation company") · **Competitors:** Slalom, Avanade, West Monroe, Eagle Hill, Pariveda.

> ⚠️ Save target is `{sharepoint_root}/positioning/`. This session can create SharePoint folders but cannot write file *content* to a site library, so this file is delivered to `output/positioning/` — drop it into `Marketing › Cowork › positioning/` (it also syncs to OneDrive Cowork).

---

## Executive summary

The market has moved past "is AI real?" Your ICP — founder-led / PE-backed mid-market leaders — is stuck three steps later: **pilots that never scale, no internal expertise to vet vendor hype, and acute governance/control anxiety** (sharpest in the PE channel). That is *exactly* Synozur's thesis: "CEOs don't need more AI hype — they need clarity, control, and confidence."

The competitive field splits cleanly. **Slalom, Avanade, and West Monroe lead AI-forward but are enterprise-scaled implementers** with visible delivery churn (layoffs, offshore reliance). **Eagle Hill and Pariveda are people/change-led but have no AI-native claim.** Your closest brand twin — **Eagle Hill** (woman-owned, change-led, mid-size) — is silent on AI. That silence is open whitespace: **"AI-native transformation company" + "human-reviewed, governed, strategy-not-staffing"** is a position none of the five can currently claim.

**Recommended primary angle:** lead with **governed, executable AI transformation for the mid-market** — wartime urgency (act now) paired with the discipline competitors' churny delivery can't promise.

---

## Positioning options (pick one to lead)

1. **"The AI-native transformation company"** — *For mid-market leaders, the only transformation advisory that is AI-native to its core and still 100% human-accountable.* **Why it works:** Eagle Hill (closest twin) has no AI claim; the AI-forward three are enterprise staff-aug. **Risk:** "AI-native" is getting crowded — must be backed by the human-review/governance substance or it reads as the hype you reject.
2. **"Governed AI, not pilot purgatory"** *(recommended lead)* — *We turn scattered AI experiments into governed, measurable outcomes — clarity, control, confidence.* **Why:** maps 1:1 to the top three ICP pains and the PE channel's explicit governance anxiety (Platinum Equity); no competitor owns governance-first AI. **Risk:** governance can read as slow — must be paired with the 4–6 week North Star Sprint so it lands as *fast + safe*.
3. **"Strategy and design, not bodies"** — *Boutique senior advisors who ship a working prototype in 4–6 weeks — no offshore, no staff-aug.* **Why:** directly exploits competitors' offshore reliance (Avanade ~40% via delivery centers) and layoff/churn reviews (Slalom, Pariveda, West Monroe). **Risk:** "boutique" can trigger scale/capacity doubts on larger deals — counter with the IP suite (Vega/Orbit/Zenith) and named proof.

---

## Content battlegrounds (where you can win)

1. **Killing pilot purgatory** — the use-case-backlog + governance playbook that actually scales AI (owns pains #1–3; competitors make vague "AI impact" claims).
2. **AI governance for PE portfolios** — control without killing speed (PE channel; Platinum Equity signal; competitors silent on PE-specific governance).
3. **"No AI slop"** — why every AI deliverable needs a human owner (ASK→REVIEW→EDIT→REPEAT); Eagle Hill/Pariveda silent, Slalom's execution reportedly lags its marketing.
4. **Microsoft-deep *and* model-agnostic** — when Copilot is the answer and when it isn't (Avanade structurally can't say this; owns your cross-platform OpenAI/Anthropic wedge).
5. **Employee effectiveness over leadership theater** — landing AI with ICs and middle managers (Chevron VoC; Eagle Hill's people-frame minus the AI).

---

## Machine-readable dossier

```json
{
  "icp_pains": [
    {"pain": "Ambition-to-execution gap (pilot purgatory)", "quote": "the gap between AI ambition and execution is costing companies millions in unrealized profit potential", "source": "Karena Bell, LinkedIn"},
    {"pain": "No internal expertise to vet vendor hype", "quote": "39% of mid-market organizations cite a lack of AI expertise as their primary barrier", "source": "Karena Bell, LinkedIn"},
    {"pain": "Governance, security & control anxiety", "quote": "Will this be part of the change? ... Does the same also apply to OpenAI?", "source": "Vincent Marino, IT Director, Platinum Equity — Outlook 'Re: Art of the Possible Follow Up'"},
    {"pain": "Fear of moving too early and getting burned", "quote": "there's a preference to wait for early adopters to work out the kinks", "source": "r/consulting (Copilot thread)"},
    {"pain": "Tools deployed but disappointing/unused", "quote": "I don't find it very useful to be honest... Personally don't think we're there yet", "source": "u/Content_Ambassador63, r/consulting"}
  ],
  "competitor_audit": [
    {"name": "Slalom", "headline": "fiercely human business and technology company that leads with outcomes", "angle": "People + results", "strongest_claim": "trusted by leaders across the majority of the Global 1000; 'Siemens activates AI for 30,000 developers'", "weakest_spot": "layoffs & AI-execution drift — 'they are behind on AI'; '900 laid off in 2023'", "ai_messaging": "Heavy/current ('AI in motion'), but reviews say execution lags marketing", "source": "slalom.com; Indeed; Wikipedia"},
    {"name": "Avanade", "headline": "Do what matters — the world's leading Microsoft expert", "angle": "Industry depth + scale", "strongest_claim": "20x Microsoft Global SI Partner of the Year; 60,000 specialists", "weakest_spot": "~40% offshore via Accenture delivery centers undercuts senior-advisor feel", "ai_messaging": "Sharpest recent shift — Agentic Platform, explicitly courting mid-market 'without the complexity that often stalls progress'", "source": "avanade.com; avanade.ai; Wikipedia"},
    {"name": "West Monroe", "headline": "Slow consulting. Fast execution.", "angle": "Speed + results", "strongest_claim": "NPS 80 (2024); '97% consider the firm a strategic advisor'", "weakest_spot": "PE-owned cost pressure — 'repeated cuts... Morale is a little low'", "ai_messaging": "Results-anchored ('$100M in value', '50% efficiency'); AI as ROI not platform", "source": "westmonroe.com; PRNewswire; Indeed"},
    {"name": "Eagle Hill", "headline": "Transform challenges into opportunities", "angle": "People + change (woman-owned)", "strongest_claim": "proprietary Employee Retention Index; Vault #1 for women", "weakest_spot": "sub-scale, below-market pay, ~75% public-sector skew limits commercial proof", "ai_messaging": "Softest — people-framed ('AI supervision is the next core analyst skill'); NO AI-native claim — Synozur's whitespace", "source": "eaglehillconsulting.com; Indeed; Management Consulted"},
    {"name": "Pariveda", "headline": "from ideas to impact... see around corners", "angle": "People + ease (employee-owned B Corp)", "strongest_claim": "one of the largest Certified B Corps in the industry", "weakest_spot": "layoff fatigue, flat/cut comp — '5 rounds of layoffs', '20% salary cuts'", "ai_messaging": "Thinnest — one homepage AI case; no AI-led transformation thesis", "source": "parivedasolutions.com; Indeed; Blind"}
  ],
  "gap_analysis": {
    "clustering": "Five competitors cluster on People/Outcomes. AI-forward trio (Slalom, Avanade, West Monroe) are enterprise-scaled implementers with delivery churn; change-led pair (Eagle Hill, Pariveda) lag on AI.",
    "unclaimed_angles": [
      "AI-native + 100% human-accountable ('no AI slop') — none claim it",
      "Governance-first AI for the mid-market and PE portfolios — unowned",
      "Microsoft-deep AND model-agnostic (OpenAI/Anthropic) — Avanade structurally can't claim it",
      "Strategy/design, not staff-aug — exploitable vs. offshore-heavy and layoff-churned rivals",
      "Boutique senior attention + 4–6 week working prototype — speed+seniority combo is open"
    ],
    "closest_comparator": "Eagle Hill (woman-owned, change-led, mid-size) — but no AI-native claim; primary whitespace target."
  },
  "voc_signals": [
    {"quote": "the gap between AI ambition and execution is costing companies millions", "source": "Karena Bell, LinkedIn", "type": "external"},
    {"quote": "watching competitors pull ahead while your organization burns resources on failed pilots", "source": "Karena Bell, LinkedIn", "type": "external"},
    {"quote": "Most mid-market teams consist of operational generalists without specialized capacity to evaluate vendor claims critically", "source": "Karena Bell, LinkedIn", "type": "external"},
    {"quote": "Will this be part of the change?", "source": "Vincent Marino, Platinum Equity — Outlook", "type": "internal-buyer"},
    {"quote": "Does the same also apply to OpenAI?", "source": "Vincent Marino, Platinum Equity — Outlook", "type": "internal-buyer"},
    {"quote": "your AI strategy, governance priorities, and the broader direction of enterprise AI", "source": "Eric Riz (Synozur) restating Platinum Equity agenda — Outlook", "type": "internal-restated"},
    {"quote": "individual contributors and middle managers, not leadership theater", "source": "Michelle Caldwell (Synozur) restating Chevron input — Outlook", "type": "internal-restated"},
    {"quote": "Where does AI actually help us do our work better—and how do we scale that responsibly?", "source": "Synozur restating Chevron need — Outlook", "type": "internal-restated"},
    {"quote": "AI is delivering faster outcomes, but it's most effective when embedded into core operational and commercial initiatives", "source": "Scott Bingham, FTI Consulting — 2026 PE Value Creation Index", "type": "external-PE"},
    {"quote": "I don't find it very useful to be honest... Personally don't think we're there yet", "source": "u/Content_Ambassador63, r/consulting", "type": "external"}
  ],
  "positioning_options": [
    {"statement": "The only mid-market transformation advisory that is AI-native to its core and 100% human-accountable.", "why": "Eagle Hill (closest twin) has no AI claim; AI-forward rivals are enterprise staff-aug.", "risk": "'AI-native' is crowding; must be backed by human-review/governance substance or reads as hype."},
    {"statement": "We turn scattered AI experiments into governed, measurable outcomes — clarity, control, confidence.", "why": "Maps 1:1 to top-3 ICP pains and the PE channel's explicit governance anxiety; no competitor owns governance-first AI.", "risk": "Governance can read as slow — pair with the 4–6 week North Star Sprint so it lands as fast+safe.", "recommended": true},
    {"statement": "Strategy and design, not bodies — boutique senior advisors who ship a working prototype in 4–6 weeks.", "why": "Exploits Avanade offshore (~40%) and layoff/churn reviews at Slalom/Pariveda/West Monroe.", "risk": "'Boutique' can trigger scale doubts on larger deals — counter with IP suite + named proof."}
  ],
  "content_battlegrounds": [
    "Killing pilot purgatory: the use-case-backlog + governance playbook that scales AI",
    "AI governance for PE portfolios: control without killing speed",
    "No AI slop: why every AI deliverable needs a human owner (ASK->REVIEW->EDIT->REPEAT)",
    "Microsoft-deep AND model-agnostic: when Copilot is the answer and when it isn't",
    "Employee effectiveness over leadership theater: landing AI with ICs and middle managers"
  ],
  "sources": [
    "slalom.com/us/en; indeed.com/cmp/Slalom-Consulting/reviews; en.wikipedia.org/wiki/Slalom_Inc",
    "avanade.com/en; avanade.ai/en; en.wikipedia.org/wiki/Avanade",
    "westmonroe.com; prnewswire.com (West Monroe rebrand); indeed.com/cmp/West-Monroe/reviews",
    "eaglehillconsulting.com; indeed.com/cmp/Eagle-Hill-Consulting/reviews; managementconsulted.com/eagle-hill-consulting",
    "parivedasolutions.com; indeed.com/cmp/Pariveda-1/reviews; teamblind.com/company/Pariveda-Solutions/reviews",
    "linkedin.com/pulse (Karena Bell, mid-market AI ROI); reddit.com/r/consulting (Copilot thread)",
    "markets.businessinsider.com (FTI 2026 PE Value Creation Index)",
    "First-party Outlook: Platinum Equity 'Art of the Possible' thread; Chevron 'Applied AI Workflow Enablement Sprints' thread"
  ]
}
```
