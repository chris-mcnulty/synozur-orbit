# 7-Day Distribution Plan (Mon Jun 8 – Sun Jun 14, 2026)

**Prepared:** 2026-06-07 · **Skill:** distribution-planner · **Package:** batch-1 drafts (#1, #3, #6, #7) + wartime-CEO repurposing package (10 assets).
**ICP time zones:** US Eastern (dominant) + Central, then Pacific/Mountain — all times ET, which also catches Central mid-morning and Pacific early.
**Anchors from calendar:** TechCon365 Chicago starts Mon Jun 15 (build toward it; Fri video teases it). Synozur Town Hall Fri Jun 12, 1 PM (internal — doesn't affect async posting). No US holiday this week (Juneteenth is Jun 19).
**Cadence respected:** 1 LinkedIn/day, ≤2 X threads staggered, 1 email (weekly cap), 1 blog publish. No piece posted twice on a platform without reformatting.

> ⚠️ Save target is `{sharepoint_root}/distribution/`. Delivered to `output/distribution/` — drop into `Marketing › Cowork › distribution/`.

```json
{
  "weekly_schedule": [
    {"day": "Mon Jun 8", "time": "9:00 AM ET", "platform": "LinkedIn", "piece": "Kill nine of your twelve AI pilots (Asset 6)", "format": "native post", "why": "Monday needs a scroll-stopper; the contrarian focus take drives comments and reach to open the week before the heavier midweek pushes.", "engagement": "Share in 2 mid-market operator / PE LinkedIn groups; comment substantively on 3 recent posts citing the FTI or BCG 2026 PE-AI reports; reply to every comment within 2 hours.", "cross_promo": "None (standalone hook)."},

    {"day": "Tue Jun 9", "time": "7:00 AM ET", "platform": "Email (newsletter)", "piece": "The wartime CEO's AI memo (#6)", "format": "email blast", "why": "Tuesday AM is peak B2B open rate; this is the week's single email send (weekly cap) and the long-form anchor everything else atomizes from.", "engagement": "Segment to CEO/COO + PE operating-partner lists; monitor replies and route Free Strategy Day requests to calendar.", "cross_promo": "Links to blog Piece A (pilots) and the Free Strategy Day CTA."},
    {"day": "Tue Jun 9", "time": "8:00 AM ET", "platform": "Blog (synozur.com/insights)", "piece": "Why 95% of AI pilots never scale (Piece A)", "format": "blog publish", "why": "Tuesday is a top publish day; seeds the LinkedIn link post and the newsletter reference on the same morning.", "engagement": "Submit to Google Search Console; ensure FAQ schema is live for AI-engine citation.", "cross_promo": "Newsletter and the 11:30 LinkedIn post both point here."},
    {"day": "Tue Jun 9", "time": "11:30 AM ET", "platform": "LinkedIn", "piece": "95% of AI pilots never scale (Batch #1)", "format": "native post + blog link in first comment", "why": "Late-morning ET catches Eastern lunch scroll and Central mid-morning; pairs with the fresh blog and newsletter for a coordinated Tuesday hit.", "engagement": "Drop the blog link in the first comment (not the post body) to protect reach; comment on 3 AI-adoption threads; tag the next Polaris guest only once that episode is announced.", "cross_promo": "Blog Piece A; references the newsletter sent at 7 AM."},

    {"day": "Wed Jun 10", "time": "8:00 AM ET", "platform": "LinkedIn", "piece": "Run your OS and AI at opposite speeds (Asset 1)", "format": "native post", "why": "Midweek thesis post; reinforces the newsletter idea for people who don't open email, in a different format.", "engagement": "Cross-post into a PE operating-partner group; comment on the latest Grant Thornton PE-AI governance thread to ride its reach.", "cross_promo": "References the wartime-CEO newsletter."},
    {"day": "Wed Jun 10", "time": "11:00 AM ET", "platform": "X", "piece": "7 signs your AI program is theater (Batch #7)", "format": "thread (8 posts)", "why": "Midday X peak; the diagnostic-checklist format drives saves and reposts.", "engagement": "Pin the thread for the day; quote-tweet the strongest sign at 3 PM; reply to anyone who self-diagnoses.", "cross_promo": "Final tweet links the pilot-to-scale playbook (blog Piece A)."},

    {"day": "Thu Jun 11", "time": "8:00 AM ET", "platform": "LinkedIn", "piece": "Only 9% could pass an AI governance audit (Asset 2)", "format": "native post", "why": "The governance stat lands hardest with the PE channel midweek; this is the highest-intent post for operating partners.", "engagement": "Tag and engage 3 PE operating partners in-network; comment on PE value-creation posts; offer the one-page AI judgment standard in replies.", "cross_promo": "Teases blog Piece B (governance) for next week; nods to the Polaris governed-AI episode."},

    {"day": "Fri Jun 12", "time": "9:30 AM ET", "platform": "X", "piece": "The four-move AI memo (Asset 4)", "format": "thread (7 posts)", "why": "Staggered two days after the first thread so the two threads don't compete; Friday AM clears before the Town Hall.", "engagement": "Reply-stack each move with a one-line example; repost the cover tweet Saturday for the weekend crowd.", "cross_promo": "Links the full playbook in the comments."},
    {"day": "Fri Jun 12", "time": "12:00 PM ET", "platform": "LinkedIn + YouTube", "piece": "Stop running twelve pilots (Asset 8, 60-sec video)", "format": "native video", "why": "Video over-indexes Friday midday; the YouTube cross-post extends to the Polaris audience and teases TechCon365 next week.", "engagement": "Post a captioned native upload (not a YouTube link) on LinkedIn for reach; add the playbook link in the YouTube description; reply to comments through the afternoon.", "cross_promo": "Mentions Synozur will be at TechCon365 Chicago (Jun 15)."},

    {"day": "Sat Jun 13", "time": "10:00 AM ET", "platform": "LinkedIn", "piece": "Clarity, control, confidence (Asset 5 carousel)", "format": "carousel (5 slides)", "why": "Carousels over-index on weekend dwell time in a lighter-competition feed; a calmer, framework-style asset suits Saturday.", "engagement": "Ask one sharp question in the post copy; respond to every comment; reshare to your featured section.", "cross_promo": "CTA: comment 'strategy day'."},

    {"day": "Sun Jun 14", "time": "—", "platform": "(rest)", "piece": "No publishing", "format": "engagement only", "why": "Protect a no-post day; B2B Sunday reach is low and the team needs runway before TechCon365 Monday.", "engagement": "15 min: clear the week's unanswered comments and queue Monday's TechCon365 real-time post.", "cross_promo": "—"}
  ],
  "recycling_plan": {
    "plus_30_days": "Re-share Batch #1 (pilots) and Asset 2 (9% governance) if they were top performers; publish blog Piece B (AI governance) + its LinkedIn link post; send Asset 7 (governance-check email snippet) as that week's single email (it was held this week to respect the weekly email cap).",
    "plus_60_days": "Asset 3 (2x ROIC) as a LinkedIn post; Asset 9 (six weeks beats a six-month deck) as a LinkedIn post; Batch #3 (no AI slop) as a LinkedIn post; Asset 10 (adoption-at-the-desk) published as a short blog + amplified on LinkedIn.",
    "plus_90_days": "Refresh blog Piece A with new 2026 stats and re-promote; re-run the best-performing carousel as a fresh design; repurpose the Polaris governed-AI episode (calendar #2) into clips once recorded.",
    "held_this_week": "Asset 7 (email snippet) — moved to next week's email slot because the newsletter used this week's send."
  },
  "engagement_blocks": [
    {"when": "Daily 8:15–8:30 AM ET", "actions": "Comment substantively (2+ sentences, a real point) on 3–5 posts from mid-market CEOs/COOs and PE operating partners in-network; prioritize anyone posting about AI adoption, Copilot, or PE value creation; like + comment on the newest FTI / BCG / Grant Thornton PE-AI report posts to borrow their reach.", "why": "Warms the exact ICP before your own post lands and signals the algorithm you're active in the right circles."},
    {"when": "Daily 1:00–1:15 PM ET", "actions": "Reply to every comment on that day's post; add value in 1–2 LinkedIn groups (mid-market operators, Microsoft partner ecosystem); engage 2 posts from Polaris guests/alumni and Microsoft MVP peers (peer reciprocity).", "why": "Comment velocity in the first hours decides reach; afternoon replies keep the post alive into the next day."}
  ]
}
```

## Plan at a glance

| Day | Time (ET) | Platform | Piece |
|-----|-----------|----------|-------|
| Mon | 9:00a | LinkedIn | Kill 9 of 12 pilots (A6) |
| Tue | 7:00a / 8:00a / 11:30a | Email · Blog · LinkedIn | Newsletter #6 · Blog Piece A · Pilots post (#1) |
| Wed | 8:00a / 11:00a | LinkedIn · X | OS vs AI speeds (A1) · Theater thread (#7) |
| Thu | 8:00a | LinkedIn | 9% governance audit (A2) |
| Fri | 9:30a / 12:00p | X · LinkedIn+YouTube | Four-move memo (A4) · Video (A8) |
| Sat | 10:00a | LinkedIn | Clarity/control/confidence carousel (A5) |
| Sun | — | rest | engagement only |

**Held for recycling:** Batch #3 (no slop), Assets 3, 7, 9, 10 — spread across +30/60/90 so the same idea never floods one week.
